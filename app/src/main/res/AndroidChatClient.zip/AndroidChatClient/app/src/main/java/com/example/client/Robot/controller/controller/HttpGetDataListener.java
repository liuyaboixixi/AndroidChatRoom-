package com.example.client.Robot.controller.controller;

public interface HttpGetDataListener {
    void getDataUrl(String result);
}
